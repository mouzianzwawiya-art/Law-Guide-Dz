// Service worker registration is handled by index.html.
